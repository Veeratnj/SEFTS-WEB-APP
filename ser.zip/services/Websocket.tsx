// websocketAPI.ts
export const websocket_api_call = (
    url: string,
    messageToSend?: string,
    onMessageCallback?: (message: string) => void
  ) => {
    const socket = new WebSocket(url);
  
    socket.onopen = () => {
      console.log('WebSocket connection established');
      if (messageToSend) {
        socket.send(messageToSend); // Send message if provided
      }
    };
  
    socket.onmessage = (event) => {
      console.log('Message from server:', event.data);
      if (onMessageCallback) {
        onMessageCallback(event.data); // Execute callback if provided
      }
    };
  
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
  
    socket.onclose = () => {
      console.log('WebSocket connection closed');
    };
  
    // Return the WebSocket object to close it when needed
    return socket;
  };
  